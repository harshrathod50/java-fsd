public class methodExecution {

    public int multiplyNumbers(int a, int b) {
        return a * b;
    }

    public static void main(String[] args) {
        methodExecution b = new methodExecution();
        int ans = b.multiplyNumbers(10, 3);
        System.out.println("Multiplication is: " + ans);
    }
}
