public class innerClassAssisted2 {
    private String msg = "\nInner Classes";

    void display() {
        class Inner {
            void msg() {
                System.out.println(msg);
            }
        }
        Inner l = new Inner();
        l.msg();
    }


    public static void main(String[] args) {
        innerClassAssisted2 obj = new innerClassAssisted2();
        obj.display();
    }
}
