package pack2;

import pack1.*;

// 4. Class having Public access specifier
public class accessSpecifiers4 {

    public static void main(String[] args) {
        System.out.println("Public Access Specifier");
        pubAccessSpecifiers obj = new pubAccessSpecifiers();
        obj.display();
    }
}
