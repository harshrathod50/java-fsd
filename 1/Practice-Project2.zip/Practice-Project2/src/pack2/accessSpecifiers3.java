package pack2;

import pack1.*;

// 3. Class having Protected access specifier
public class accessSpecifiers3 extends proAccessSpecifiers {

    public static void main(String[] args) {
        System.out.println("Protected Access Specifier");
        accessSpecifiers3 obj = new accessSpecifiers3();
        obj.display();
    }
}
