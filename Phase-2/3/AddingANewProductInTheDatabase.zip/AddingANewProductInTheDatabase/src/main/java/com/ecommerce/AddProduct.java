package com.ecommerce;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.ecommerce.entity.EProduct;

@WebServlet("/AddProduct")
public class AddProduct extends HttpServlet {

	public AddProduct() {
		super();
	}

	protected void doPost(
		HttpServletRequest request,
		HttpServletResponse response
	) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session s = sf.openSession();
		EProduct p = new EProduct();
		p.setName(request.getParameter("name"));
		p.setPrice(new BigDecimal(request.getParameter("price")));
		s.save(p);
		s.close();
		out.println("<h1>Product added!</h1><br>");
		out.println("</body></html>");
	}
}
