package com.ecommerce;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

@WebServlet("/EProduct")
public class EProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public EProduct() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		InputStream in = this.getServletContext().getResourceAsStream("/WEB-INF/config.properties");
		Properties props = new Properties();
		props.load(in);
		try {
			DbUtil db = new DbUtil(
				props.getProperty("url"),
				props.getProperty("username"),
				props.getProperty("password")
			);
			out.print("<html><body>");
			PreparedStatement ps = db.getConnection().prepareStatement(
				"SELECT * FROM eproduct WHERE id = ?"
			);
			ps.setInt(1, Integer.parseInt(request.getParameter("productId")));
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				out.println("<h1>PRODUCT FOUND!</h1>");
				out.printf(
					"%s, %s, %s<br>",
					rs.getInt("id"),
					rs.getString("name"),
					rs.getDate("date_added")
				);
			}
			rs.close();
			out.print("</body></html>");
			db.closeConnection();
		} catch(Exception e) {
			//
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
