package com.ecommerce;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledIf;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;

@DisplayName("JUnit 5 Conditional Tests Example")
public class ConditionalTests {

  @Test
  @EnabledOnOs({ OS.WINDOWS })
  void runOnWindows() {
    System.out.println("This test runs on Windows.");
  }

  @Test
  @EnabledOnOs({ OS.LINUX })
  void runOnLinux() {
    System.out.println("This test runs on Linux.");
  }

  @Test
  @EnabledOnOs({ OS.MAC })
  void runOnMac() {
    System.out.println("This test runs on Macintosh.");
  }

  boolean randomCondition() {
    return Math.random() > 0.5;
  }

  @Test
  @DisabledIf("randomCondition")
  void mayOrMayNotExecute() {
    System.out.println("This test may or may not execute.");
  }
}
