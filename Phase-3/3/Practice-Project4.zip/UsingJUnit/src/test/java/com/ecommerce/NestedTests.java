package com.ecommerce;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

@DisplayName("JUnit 5 Nested Tests Example")
public class NestedTests {

  @BeforeAll
  static void beforeAll() {
    System.out.println("Before all test methods");
  }

  @BeforeEach
  void beforeEach() {
    System.out.println("Before each test method");
  }

  @Nested
  @DisplayName("Nested Class A")
  class A {

    @BeforeEach
    void beforeEach() {
      System.out.println("A: Before each test method");
    }

    @Nested
    @DisplayName("Sub-sub-nested class B")
    class B {

      @BeforeEach
      void beforeEach() {
        System.out.println("B: Before each test method");
      }

      @Test
      void sampleTestForClassB() {
        System.out.println("sample test for class B");
      }

      @AfterEach
      void afterEach() {
        System.out.println("B: After each test method");
      }
    }

    @Test
    void sampleTestForClassA() {
      System.out.println("sample test for class A");
    }

    @AfterEach
    void afterEach() {
      System.out.println("A: After each test method");
    }
  }

  @AfterEach
  void afterEach() {
    System.out.println("After each test method");
  }

  @AfterAll
  static void AfterAll() {
    System.out.println("After all test methods");
  }
}
