package com.ecommerce;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

@DisplayName("JUnit 5 Repeated Tests Example")
public class RepeatedTests {

  @BeforeAll
  static void init() {
    System.out.println("Before all init() method called");
  }

  @BeforeEach
  void initEach() {
    System.out.println("Before all initEach() method called");
  }

  @RepeatedTest(5)
  @DisplayName("add operation test")
  void addNumber() {
    assertEquals(5, Calculator.add(3, 2));
    System.out.println("addNumber test case executed");
  }

  @AfterEach
  void cleanUpEach() {
    System.out.println("After each cleanUpEach() method called");
  }

  @AfterAll
  static void cleanUp() {
    System.out.println("After allll cleanUp() method called");
  }
}
