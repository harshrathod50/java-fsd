package com.ecommerce;

public class Calculator {

  public static int add(int x, int y) {
    return x + y;
  }

  private Calculator() {
  }
}
